from peewee import *

connect = MySQLDatabase(
    'violationno',
    user='root',
    password='12345',
    host='localhost'
)


