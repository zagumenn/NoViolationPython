from Config.Connect import *

class BaseModel(Model):
    class Meta:
        database = connect

class Roles(BaseModel):
    role = CharField()
    id = PrimaryKeyField()

def test_show():
    for row in Roles.select():
        print(row.role)

if __name__ == "__main__":
    test_show()