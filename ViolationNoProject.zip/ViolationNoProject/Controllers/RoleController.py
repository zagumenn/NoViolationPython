# Этот контроллер управляет записями в таблице класс Roles
# с помощью модели Role СRUD
from Models.Role import *

class RoleController():
    # показать все роли
    def show(self):
        return Roles.select().execute()

    # метод создания роли
    def create(self, name_role):
        Roles.create(role = name_role)

    # метод обновления роли
    def update(self, old_name, new_name):
        Roles.update({Roles.role: new_name}).where(Roles.role == old_name).execute()

    # метод удаления роли
    def delete(self, name_delete):
        Roles.delete().where(Roles.role == name_delete).execute()

if __name__ == "__main__":
    role = RoleController()

    # проверить метод show
    for row in role.show():
        print(row.id, row.role)
    print("----------------")
    #role.create("root")
    #role.update('superroot')
    #role.delete('superroot')
    for row in role.show():
        print(row.id, row.role)