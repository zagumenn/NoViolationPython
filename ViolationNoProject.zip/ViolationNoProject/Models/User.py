from Models.Base import *
from Models.Role import *

class Users(BaseModel):
    id = PrimaryKeyField()
    login = CharField()
    password = CharField()
    fullname = CharField()
    email = CharField()
    phone = IntegerField()
    role_id = ForeignKeyField(Roles)