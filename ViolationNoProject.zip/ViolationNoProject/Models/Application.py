from Models.Base import *
from Models.User import *

class Applications(BaseModel):
    id = PrimaryKeyField()
    discription = TextField()
    status = CharField()
    number_auto = CharField()
    user_id = ForeignKeyField(Users)