# Этот контроллер управляет записями в таблице класс Applications
# с помощью модели Aplication СRUD
from Models.Application import *

class ApplicationController():
    # показать все заявления
    def show(self):
        return Applications.select()

    # метод создания заявления
    def create(self, input_discription, input_status, input_number_auto, input_user_id):
        Applications.create(discription = input_discription, status = input_status, number_auto = input_number_auto, user_id = input_user_id)

    def show_one(self, us_id):
        return Applications.select().where(Applications.user_id == us_id)

    # метод обновления заявления
    def update_status(self, discription_id, new_status):
        Applications.update({Applications.status: new_status}).where(Applications.id == discription_id).execute()

    # метод удаления заявления
    def delete(self, discription_id):
        Applications.delete().where(Applications.id == discription_id).execute()

if __name__ == "__main__":
    app = ApplicationController()
    print(app.show())
    for row in app.show():
        print(row.id, row.user_id.fullname, row.discription, row.number_auto, row.status)
