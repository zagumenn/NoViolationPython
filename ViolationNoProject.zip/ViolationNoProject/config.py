host = "127.0.0.1"
user = "root"
password = "12345"
db_name = "violationno"