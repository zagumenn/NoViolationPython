from Config.Connect import *

class BaseModel(Model):

    class Meta:
        database = connect
