from Models.User import *


class UserController():

    # ищем логин и пароль в базе данных
    def login(self, input_login, input_password):
        # ищем логин и пароль в базе данных
        if Users.select().where(Users.login == input_login) and Users.get(Users.login == input_login).password == input_password:
            return True
        else:
            return False

    # проверка авторизации администратора
    def login_adm(self, input_login, input_password):
        if self.login(input_login, input_password) and Users.get(Users.login == input_login).role_id.id == 1:
            return True
        else:
            return False


    # Регистрация - создания записи в таблице Users
    def registration(self, input_login, input_password, input_fullname, input_email, input_phone):
        Users.create(login = input_login, password=input_password, fullname=input_fullname, email=input_email,
                     phone=input_phone, role_id= Roles.get(Roles.role == 'user').id)

    # вывод id пользователя по его логину
    def get_id_user(self, login):
        return Users.get(Users.login == login)

if __name__ == "__main__":
    us = UserController()

    print(us.login('copp1', 'pass'))
    print(us.login_adm('qqq', '1233421'))
    #print(us.registration('copp', '123', '', '', ''))
    #print(us.get_id_user('copp'))